<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
    header("location: index.php");
    exit;
}
include "includes/connection.php";
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/dashboard.css">
</head>

<body>
    <?php include "nav.php"; ?>
    <h1>Welcome Admin!</h1>
    <div class="container">
        <div class="card red-gradient">
            <a href="manage-students.php" class="stretched-link" style="text-decoration:none; color:white;">
                No. of Students
                <p id="s1">0</p>
            </a>
        </div>

        <div class="card blue-gradient">
            <a href="manage-sem.php" class="stretched-link" style="text-decoration:none; color:white;">
                Semesters Listed
                <p id="s2">0</p>
            </a>
        </div>

        <div class="card green-gradient">
            <a href="manage-branch.php" class="stretched-link" style="text-decoration:none; color:white;">
                Branches Listed
                <p id="s3">0</p>
            </a>
        </div>

        <div class="card yellow-gradient">
            <a href="manage-subjects.php" class="stretched-link" style="text-decoration:none; color:white;">
                Subjects Listed
                <p id="s4">0</p>
            </a>
        </div>

        <div class="card purple-gradient">
            <a href="manage-results.php" class="stretched-link" style="text-decoration:none; color:white;">
                Results Declared
                <p id="s5">0</p>
            </a>
        </div>
    </div>

    <script>
        function animateValue(obj, start, end, duration) {
            let startTimestamp = null;
            const step = (timestamp) => {
                if (!startTimestamp) startTimestamp = timestamp;
                const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                obj.innerHTML = Math.floor(progress * (end - start) + start);
                if (progress < 1) {
                    window.requestAnimationFrame(step);
                }
            };
            window.requestAnimationFrame(step);
        }

        const obj1 = document.getElementById("s1");
        const obj2 = document.getElementById("s2");
        const obj3 = document.getElementById("s3");
        const obj4 = document.getElementById("s4");
        const obj5 = document.getElementById("s5");

        // PHP block directly inside JS (fixed structure)
        <?php
        // Fetch number of students
        $sql1 = "SELECT COUNT(*) as total_students FROM student";
        $result1 = mysqli_query($conn, $sql1);
        $row1 = mysqli_fetch_assoc($result1);
        $num1 = $row1['total_students'];

        // Fetch number of semesters
        $sql2 = "SELECT COUNT(*) as total_semesters FROM semester";
        $result2 = mysqli_query($conn, $sql2);
        $row2 = mysqli_fetch_assoc($result2);
        $num2 = $row2['total_semesters'];

        // Fetch number of branches
        $sql3 = "SELECT COUNT(*) as total_branches FROM branch";
        $result3 = mysqli_query($conn, $sql3);
        $row3 = mysqli_fetch_assoc($result3);
        $num3 = $row3['total_branches'];

        // Fetch number of subjects
        $sql4 = "SELECT COUNT(*) as total_subjects FROM subjects";
        $result4 = mysqli_query($conn, $sql4);
        $row4 = mysqli_fetch_assoc($result4);
        $num4 = $row4['total_subjects'];

        // Fetch number of declared results
        $sql5 = "SELECT COUNT(DISTINCT roll_no) as total_results FROM results";
        $result5 = mysqli_query($conn, $sql5);
        $row5 = mysqli_fetch_assoc($result5);
        $num5 = $row5['total_results'];
        ?>

        // Assign the PHP values to animateValue function
        animateValue(obj1, 0, <?php echo $num1; ?>, 800);
        animateValue(obj2, 0, <?php echo $num2; ?>, 800);
        animateValue(obj3, 0, <?php echo $num3; ?>, 800);
        animateValue(obj4, 0, <?php echo $num4; ?>, 800);
        animateValue(obj5, 0, <?php echo $num5; ?>, 800);
    </script>
</body>

</html>
