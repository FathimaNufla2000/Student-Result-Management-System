<?php
session_start();
$showAlert = false;
$showError = false;
include "includes/connection.php";
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
else{
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $fullname = $_POST['fullname'];
        $rollno = $_POST['rollno'];
        $email = $_POST['email'];
        $gender = $_POST['gender'];
        $dob = $_POST['birthDate'];
        $branch = $_POST['branch'];
        $sem = $_POST['semester'];
        $status = 1;
        $addsql = "INSERT INTO `student` (`Name`, `Roll_No`, `Email`, `Gender`, `DOB`, `branch_id`, `Reg_date`, `sem_id`, `status`) 
                    VALUES ('$fullname','$rollno', '$email', '$gender', '$dob', '$branch', current_timestamp(), '$sem', '$status') ";
        $result = mysqli_query($conn, $addsql);
        if($result){
            $showAlert = true;
        }
        else{
            $showError = true;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Students</title>

    <!-- Bootstrap CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+Y5kk+25RkFIo1x4gHzRoeEo+P3YJ" crossorigin="anonymous">

    <!-- Font Awesome CDN for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Custom CSS for Dark Theme -->
    <style>
        body {
            margin: 0;
            background: linear-gradient(135deg, #232526, #414345); /* Dark gradient */
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            color: white;
        }
        .container {
            background-color: white;
            padding: 30px;
            margin-top: 30px;
            border-radius: 8px;
            box-shadow: 0px 0px 15px rgba(0,0,0,0.1);
            max-width: 700px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-control {
            font-size: 16px;
        }
        .btn-submit {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            font-size: 17px;
            border: none;
            border-radius: 5px;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<?php include "nav.php"; ?>

<!-- Alert messages -->
<?php if($showAlert) { echo '<div class="alert alert-success alert-dismissible fade show" role="alert">Record Added Successfully!</div>'; } ?>
<?php if($showError) { echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">Error! Please Try Again.</div>'; } ?>

<div class="container">
    <h2>Add Student Details</h2>
    <form method="post">
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="fullname" class="form-label">Full Name</label>
                <input type="text" class="form-control" name="fullname" id="fullname" placeholder="Enter full name" required>
            </div>
            <div class="col-md-6">
                <label for="rollno" class="form-label">Roll No</label>
                <input type="text" class="form-control" name="rollno" id="rollno" placeholder="Enter roll number" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" name="email" id="email" placeholder="Enter email address" required>
            </div>
            <div class="col-md-6">
                <label for="birthDate" class="form-label">Date of Birth</label>
                <input type="date" class="form-control" name="birthDate" id="birthDate" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">Gender</label>
                <div>
                    <input type="radio" name="gender" value="Male" id="genderMale" required>
                    <label for="genderMale">Male</label>
                    <input type="radio" name="gender" value="Female" id="genderFemale" style="margin-left: 20px;" required>
                    <label for="genderFemale">Female</label>
                    <input type="radio" name="gender" value="Other" id="genderOther" style="margin-left: 20px;" required>
                    <label for="genderOther">Other</label>
                </div>
            </div>
            <div class="col-md-6">
                <label for="branch" class="form-label">Branch</label>
                <select class="form-select" name="branch" id="branch" required>
                    <option value="" selected>Select Branch</option>
                    <?php 
                    $sql = "SELECT * from `branch`";
                    $result = mysqli_query($conn, $sql);
                    while($row = mysqli_fetch_assoc($result)) {
                    ?>
                        <option value="<?php echo $row['branch_id']; ?>"><?php echo $row['branch']; ?></option>
                    <?php } ?>
                </select>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="semester" class="form-label">Semester</label>
                <select class="form-select" name="semester" id="semester" required>
                    <option value="" selected>Select Semester</option>
                    <?php 
                    $sql = "SELECT * from `semester`";
                    $result = mysqli_query($conn, $sql);
                    while($row = mysqli_fetch_assoc($result)) {
                    ?>
                        <option value="<?php echo $row['sem_id']; ?>"><?php echo $row['semester']; ?></option>
                    <?php } ?>
                </select>
            </div>
        </div>

        <div class="d-flex justify-content-end">
            <button type="submit" class="btn btn-submit">Add Student</button>
        </div>
    </form>
</div>

<!-- Bootstrap JS CDN -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76A2z02tE3zMycps2N/CZkE7/q03UmoNL8kE4gNfWX/Y2z0vPl1hbTxaHhnl9fi" crossorigin="anonymous"></script>

</body>
</html>
