<?php
session_start();
$showAlert = false;
$showError = false;
include "includes/connection.php";

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
} else {
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $sem = $_POST['semester'];

        $addsql = "INSERT INTO `semester` (`semester`) VALUES ('$sem') ";
        $result = mysqli_query($conn, $addsql);
        if($result){
            $showAlert = true;
        } else {
            $showError = true;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Semester</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-kenU1KFdBIe4zVF0sG1M5b4hcpxyD9F7jL+Y5kk+25RkFIo1x4gHzRoeEo+P3YJ" crossorigin="anonymous">

    <!-- Custom CSS for Dark Theme -->
    <style>
        body {
            margin: 0;
            background: linear-gradient(135deg, #232526, #414345); /* Dark gradient */
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            color: white;
        }
        .container {
            background-color: white;
            padding: 30px;
            margin-top: 30px;
            border-radius: 8px;
            box-shadow: 0px 0px 15px rgba(0,0,0,0.1);
            max-width: 600px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-control {
            font-size: 16px;
        }
        .btn-submit {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            font-size: 17px;
            border: none;
            border-radius: 5px;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
        .btn-cancel {
            margin-left: 10px;
            background-color: #6c757d;
            color: white;
            padding: 10px 20px;
            font-size: 17px;
            border: none;
            border-radius: 5px;
        }
        .btn-cancel:hover {
            background-color: #5a6268;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<?php include "nav.php"; ?>

<!-- Alert messages -->
<?php
if($showAlert){
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">Semester Added Successfully!</div>';
}
if($showError){
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">Error! Please Try Again.</div>';
}
?>

<div class="container">
    <form method="post">
        <h2>Add Semester</h2>
        <div class="mb-3">
            <label for="semester" class="form-label">Semester</label>
            <input name="semester" class="form-control" placeholder="Enter semester name" required />
        </div>

        <div class="d-flex justify-content-end">
            <button type="submit" class="btn btn-submit">Add</button>
            <a href="dashboard.php" class="btn btn-cancel">Cancel</a>
        </div>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76A2z02tE3zMycps2N/CZkE7/q03UmoNL8kE4gNfWX/Y2z0vPl1hbTxaHhnl9fi" crossorigin="anonymous"></script>

</body>
</html>
